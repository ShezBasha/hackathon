#mypackage
This library was created to return functions using a recursion module and a sorting module

## building this package locally
`python setup.py sdist`

## installing this package from
`pip install git+https://github.com/ShezBasha/mypackage.git`

## updating this package from
`pip install --upgrade git+https://github.com/ShezBasha/mypackage.git` 
